package com.bakery.BakeryApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BakeryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BakeryAppApplication.class, args);
	}

}
