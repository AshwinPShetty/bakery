package com.bakery.BakeryApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BakeryAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
